<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['width' => 110,'height'=>32]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['width' => 110,'height'=>32]); ?>
<?php foreach (array_filter((['width' => 110,'height'=>32]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<img src="/static/logo.svg" width="$width" height="$height"
    alt="Tabler" class="navbar-brand-image"><?php /**PATH D:\Project\Laravel\sistemta\resources\views/components/tabler-logo.blade.php ENDPATH**/ ?>