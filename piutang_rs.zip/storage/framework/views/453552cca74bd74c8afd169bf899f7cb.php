<col-12 class="col-md-6">
    <div class="mb-2">
        <label for class="form-label col-12 col-md-4 fw-bold">Nama lengkap</label>
        <input type="text" name="name"
            class="form-control"
            value="<?php echo e(old('name',$pengguna->name)); ?>"
            placeholder="Masukan Nama lengkap" />
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger fst-italic"><?php echo e($errors->first('name')); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-2">
        <label for class="form-label col-12 col-md-4 fw-bold">Email</label>
        <input type="email" name="email" class="form-control"
            value="<?php echo e(old('email',$pengguna->email)); ?>"
            placeholder="Masukan Email" />
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger fst-italic"><?php echo e($errors->first('email')); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-2">
        <label for class="form-label col-12 col-md-4 fw-bold">Password</label>
        <input type="password" name="password" class="form-control"
            placeholder="Masukan Password" />
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger fst-italic"><?php echo e($errors->first('password')); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-2">
        <label for class="form-label col-12 col-md-4 fw-bold">Role</label>
        <select name="role" class="form-control">
            <option value>Pilih role</option>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($role->name); ?>"
                <?php echo e(old('role',$pengguna->getRoleNames()->first()) == $role->name
                ? 'selected' : ''); ?>

                ><?php echo e($role->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger fst-italic"><?php echo e($errors->first('role')); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-2">
        <label for class="form-label col-12 col-md-4 fw-bold">Foto profil</label>
        <input type="file" name="image" class="form-control" />
        <?php if($pengguna->getFirstMediaUrl('pengguna','preview') != ''): ?>
        <div class="mt-3">
            <img src="<?php echo e($pengguna->getFirstMediaUrl('pengguna','preview')); ?>"
                class="rounded"
                style="width:100px; object-fit: cover;" />
        </div>
        <?php endif; ?>
    </div>
</col-12><?php /**PATH D:\Project\Laravel\sistemta\resources\views/pengguna/_form.blade.php ENDPATH**/ ?>