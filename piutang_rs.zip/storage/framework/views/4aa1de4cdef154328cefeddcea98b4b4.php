<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12">
            <div class="mb-4">
                <h2>Data <?php echo e($title); ?></h2>
            </div>

            <?php if(session('status') == 'create-success'): ?>
            <div class="alert alert-success alert-dismissible fade show"
                role="alert">
                <strong>Sukses !</strong> Insert data berhasil.
                <button type="button" class="btn-close" data-bs-dismiss="alert"
                    aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <?php if(session('status') == 'update-success'): ?>
            <div class="alert alert-success alert-dismissible fade show"
                role="alert">
                <strong>Sukses !</strong> Update data berhasil.
                <button type="button" class="btn-close" data-bs-dismiss="alert"
                    aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <?php if(session('status') == 'delete-success'): ?>
            <div class="alert alert-success alert-dismissible fade show"
                role="alert">
                <strong>Sukses !</strong> Hapus data berhasil.
                <button type="button" class="btn-close" data-bs-dismiss="alert"
                    aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body border-bottom py-3">
                    <div class="d-flex">
                        <div class="text-secondary">
                            <a href="<?php echo e(route('jenis-perawatan.create')); ?>"
                                class="btn btn-primary">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                    class="icon icon-tabler icon-tabler-plus p-0 m-0"
                                    width="24" height="24" viewBox="0 0 24 24"
                                    stroke-width="2" stroke="currentColor"
                                    fill="none" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z"
                                        fill="none"></path>
                                    <path d="M12 5l0 14"></path>
                                    <path d="M5 12l14 0"></path>
                                </svg>
                                <span class="d-none d-md-inline">Tambah</span>
                            </a>
                        </div>
                        <div class="ms-auto text-secondary ">
                            <form method="GET"
                                action="<?php echo e(route('jenis-perawatan.index')); ?>">
                                <div class="ms-2 d-flex">
                                    <input type="text"
                                        class="form-control me-1"
                                        name="search"
                                        value="<?php echo e(request('search')); ?>"
                                        aria-label="Search invoice">
                                    <button class="btn btn-primary">Cari</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table
                        class="table card-table table-vcenter text-nowrap datatable table-stripped table-sm ">
                        <thead>
                            <tr>
                                <th style="width: 60px;">No.</th>
                                <th class="col-2">Nama Perawatan</th>
                                <th class="col-1">Biaya (default)</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 0;
                            $no = ($jenisPerawatans->perPage() *
                            $jenisPerawatans->currentPage()) -
                            $jenisPerawatans->perPage()
                            ?>
                            <?php $__currentLoopData = $jenisPerawatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenisPerawatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-secondary"><?php echo e(++$no); ?></td>
                                <td class="text-secondary py-3"><?php echo e($jenisPerawatan->nama); ?></td>
                                <td>
                                    <?php echo e($jenisPerawatan->biayaInRupiah()); ?>

                                </td>
                                <td class="text-end">
                                    <span class="dropdown">
                                        <button
                                            class="btn dropdown-toggle"
                                            data-bs-boundary="viewport"
                                            data-bs-toggle="dropdown">Aksi</button>
                                        <div
                                            class="dropdown-menu">
                                            <a class="dropdown-item"
                                                href="<?php echo e(route('jenis-perawatan.edit',$jenisPerawatan->id)); ?>">
                                                Edit
                                            </a>
                                            <a class="dropdown-item"
                                                form="delete" href="#"
                                                onclick="showingDeleteConfirmation(this,<?php echo e($jenisPerawatan->id); ?>)">
                                                Delete
                                            </a>
                                            <form class="d-none"
                                                id="delete<?php echo e($jenisPerawatan->id); ?>"
                                                method="POST"
                                                action="<?php echo e(route('jenis-perawatan.destroy',$jenisPerawatan->id)); ?>">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </div>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer d-flex align-items-center">
                    <?php echo $jenisPerawatans->appends(request()->query())->links(); ?>

                </div>
            </div>
        </div>
    </div>
    <script>
        function showingDeleteConfirmation(form,id){
            let isConfirm = confirm('Hapus data ini ?');
            if(isConfirm){
                form.nextElementSibling.submit()
            }
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Project\Laravel\piutang_rs\resources\views/jenis-perawatan/index.blade.php ENDPATH**/ ?>