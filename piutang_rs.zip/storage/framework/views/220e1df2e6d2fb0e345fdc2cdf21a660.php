<col-12 class="col-md-6">
    <div class="mb-2">
        <label for class="form-label col-12 col-md-4 fw-bold">Nama lengkap</label>
        <input type="text" name="nama"
            class="form-control"
            value="<?php echo e(old('nama',$pasien->nama)); ?>"
            placeholder="Masukan Nama Lengkap Pasien" />
        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger fst-italic"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-2">
        <label for class="form-label col-12 col-md-4 fw-bold">No RM</label>
        <input type="text" name="no_rm"
            class="form-control"
            value="<?php echo e(old('no_rm',$pasien->no_rm)); ?>"
            placeholder="Masukan Nomor Rekam medis Pasien" />
        <?php $__errorArgs = ['no_rm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger fst-italic"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for class="form-label col-12 col-md-4 fw-bold">Alamat Pasien</label>
        <textarea class="form-control" name="alamat"
            rows="5"
            placeholder="Masukan alamat pasien"><?php echo e(old('alamat',$pasien->alamat)); ?></textarea>
        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger fst-italic"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3 form-check">
        <input class="form-check-input" type="checkbox" value="1"
            name="asli_daerah"
            <?php if(old('asli_daerah',$pasien->asli_daerah)): echo 'checked'; endif; ?>
        id="flexCheckChecked"/>
        <label class="form-check-label" for="flexCheckChecked">
            Masyarakat asli daerah (Purworejo)
        </label>
        <small class="text-muted fst-italic">Centang jika pasien merupakan warga
            asli Purworejo.</small>
        <?php $__errorArgs = ['asli_daerah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger fst-italic"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</col-12><?php /**PATH D:\Project\Laravel\piutang_rs\resources\views/pasien/_form.blade.php ENDPATH**/ ?>