<section>
    <?php if(session('status') === 'profile-updated'): ?>
    <div class="alert alert-success alert-dismissible fade show mt-2"
        role="alert">
        <strong>Sukses </strong> Profil berhasil diperbarui.
        <button type="button" class="btn-close" data-bs-dismiss="alert"
            aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <div class="card">
        <div
            class="card-header flex-column align-items-start">
            <span class="h3">Informasi Profil</span>
            <span>Perbarui informasi profil dan alamat email</span>
        </div>
        <div class="card-body">

            <form method="post" id="ProfileUpdate"
                action="<?php echo e(route('profile.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="mb-3">
                    <label class="form-label">Nama lengkap</label>
                    <input type="text" name="name" id
                        value="<?php echo e(old('name',$user->name)); ?>" class="form-control">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="text" name="email" id
                        value="<?php echo e(old('email',$user->email)); ?>"
                        class="form-control">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </form>

        </div>
        <div class="card-footer">
            <button form="ProfileUpdate" type="submit"
                class="btn btn-primary">Perbarui</button>
        </div>
    </div>
</section>
<?php /**PATH D:\Project\Laravel\sistemta\resources\views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>