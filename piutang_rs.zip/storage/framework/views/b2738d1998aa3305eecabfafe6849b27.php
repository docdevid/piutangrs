<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12">
            <div class="mb-4">
                <h2>Detail <?php echo e($title); ?></h2>
            </div>
            <div class="card">
                <div class="card-body py-3">
                    <div class="row">
                        <div class="col-12 col-md-8">
                            <h2><?php echo e($pasien->nama); ?> (<?php echo e($pasien->no_rm); ?>)</h2>
                            <table class="table table-borderless table-sm">
                                <tr class="align-top">
                                    <td class="text-muted col-2">Terdaftar</td>
                                    <td class><?php echo e($pasien->created_at->format('d M Y')); ?></td>
                                </tr>
                                <tr class="align-top">
                                    <td class="text-muted">Didaftarkan
                                        oleh</td>
                                    <td class><?php echo e($pasien->creator->name ?? '-'); ?></td>
                                </tr>
                                <tr class="align-top">
                                    <td class="text-muted">Alamat</td>
                                    <td class><?php echo e($pasien->alamat); ?></td>
                                </tr>
                                <tr class="align-middle">
                                    <td class="text-muted">Asli
                                        Purworejo</td>
                                    <td class><?php echo $pasien->asli_daerah
                                        ? '<span class="text-success">Yes</span>' : '<span
                                            class="text-danger">Yes</span>'; ?></td>
                                </tr>
                            </table>

                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center">
                    <a href="<?php echo e(route('pasien.index')); ?>" class="btn">Kembali</a>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Project\Laravel\piutang_rs\resources\views/pasien/show.blade.php ENDPATH**/ ?>