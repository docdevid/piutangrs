<section>
    <?php if(session('status') === 'profile-picture-updated'): ?>
    <div class="alert alert-success alert-dismissible fade show mt-2"
        role="alert">
        <strong>Sukses </strong> Foto Profil berhasil diperbarui.
        <button type="button" class="btn-close" data-bs-dismiss="alert"
            aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <div class="card">
        <div
            class="card-header flex-column align-items-start">
            <span class="h3">Foto Profil</span>
        </div>
        <div class="card-body">

            <form method="post" id="ProfilePictureUpdate"
                action="<?php echo e(route('profile-picture.update')); ?>"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="mb-3">
                    <label class="form-label">Foto profil</label>
                    <input type="file" name="image" class="form-control">
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <?php if($user->getFirstMediaUrl('pengguna')): ?>
                <div>
                    <img src="<?php echo e($user->getFirstMediaUrl('pengguna','preview')); ?>"
                        style="width:6rem;height: 6rem;object-fit: cover;"
                        class="rounded" />
                </div>
                <?php endif; ?>
            </form>
        </div>
        <div class="card-footer">
            <button form="ProfilePictureUpdate" type="submit"
                class="btn btn-primary">Perbarui</button>
        </div>
    </div>
</section>
<?php /**PATH D:\Project\Laravel\piutang_rs\resources\views/profile/partials/update-profile-picture-form.blade.php ENDPATH**/ ?>