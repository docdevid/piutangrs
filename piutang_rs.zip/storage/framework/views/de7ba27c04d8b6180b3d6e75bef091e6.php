<col-12 class="col-md-6">
    <div class="mb-2">
        <label for class="form-label col-12 col-md-4 fw-bold">Nama Jenis
            Perawatan</label>
        <input type="text" name="nama"
            class="form-control"
            value="<?php echo e(old('nama',$jenisPerawatan->nama)); ?>"
            placeholder="Masukan Nama Jenis Perawatan" />
        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger fst-italic"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-2">
        <label for class="form-label col-12 col-md-4 fw-bold">Biaya Perawatan
            (default)</label>
        <input type="number" name="biaya"
            class="form-control"
            value="<?php echo e(old('biaya',$jenisPerawatan->biaya)); ?>"
            placeholder="Masukan Biaya Perawatan" />
        <?php $__errorArgs = ['biaya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger fst-italic"><?php echo e($message); ?></span>
        <br />
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <small class="fst-italic">Untuk biaya perawatan bisa untuk tidak diisi.</small>
    </div>
</col-12><?php /**PATH D:\Project\Laravel\piutang_rs\resources\views/jenis-perawatan/_form.blade.php ENDPATH**/ ?>