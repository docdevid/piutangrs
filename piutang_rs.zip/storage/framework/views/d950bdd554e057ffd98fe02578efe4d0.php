<?php

$bulan = array(
1 => "Januari",
2 => "Februari",
3 => "Maret",
4 => "April",
5 => "Mei",
6 => "Juni",
7 => "Juli",
8 => "Agustus",
9 => "September",
10 => "Oktober",
11 => "November",
12 => "Desember"
);

?>

<?php for($i = 1; $i <=count($bulan);$i++): ?>
<?php
$data[$i] = $piutangs->filter(function($v,$index)use($i){
return $v->created_at->month == $i;
})
?>
<?php endfor; ?>

<?php for($i = 1; $i <=count($bulan);$i++): ?>

<?php if(count($data[$i]) > 0): ?>
<?php
$data_ = $data[$i]
?>
<table>
    <tr>
        <th colspan="16"
            style="text-align: center;font-weight: bold;font-size: 16px;">Daftar
            Piutang Pasien Tahun <?php echo e($year); ?></th>
    </tr>
    <tr>
        <th colspan="16"
            style="text-align: center;font-weight: bold;font-size: 16px;">RSUD
            dr.
            TJITROWARDOJO KABUPATEN PURWOREJO</th>
    </tr>
    <tr>
        <th colspan="16"
            style="text-align: center;font-weight: bold;font-size: 16px;">KEADAAN
            PER <?php echo e($bulan[$i]); ?> <?php echo e($year); ?></th>
    </tr>
</table>
<table>
    <thead>
        <tr style="border:1px solid black;border-collapse: collapse;">
            <th
                style="width:40px;text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;"
                rowspan="2">No.</th>
            <th
                style="width:150px;text-align:left;font-weight:bold;border:1px solid black;border-collapse: collapse;"
                rowspan="2">Nama Pasien</th>
            <th
                style="width:100px;text-align:left;font-weight:bold;border:1px solid black;border-collapse: collapse;"
                rowspan="2">No Rekam Medis
            </th>
            <th
                style="width:75px;text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;"
                colspan="2">Tanggal</th>
            <th
                style="width:50px;text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;"
                rowspan="2">Zaal</th>
            <th
                style="width:150px;text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;"
                colspan="<?php echo e($jenisPerawatans->count()); ?>">
                Biaya
                Perawatan</th>
            <th
                style="width:75px;text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;"
                rowspan="2">
                <span>Total</span></th>
            <th
                style="width:75px;text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;"
                rowspan="2"><span
                    class>Cicilan</span></th>
            <th
                style="width:75px;text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;"
                rowspan="2"><span
                    class>Sisa</span></th>
            <th
                style="width:75px;text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;"
                rowspan="2"><span
                    class>Ket</span></th>
        </tr>
        <tr>
            <th
                style="width:100px;text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;">Masuk</th>
            <th
                style="width:100px;text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;">Keluar</th>
            <?php $__currentLoopData = $jenisPerawatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th
                style="width:75px;text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;">
                <span><?php echo e($jenis->nama); ?></span></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 0;
        $total_biaya_perawatan = [];
        $total_total = 0;
        $total_cicilan = 0;
        $total_sisa = 0;
        ?>
        <?php $__currentLoopData = $data_; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piutang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td
                style="text-align:center;border:1px solid black;border-collapse: collapse;"><?php echo e(++$no); ?></td>
            <td
                style="text-align:left;border:1px solid black;border-collapse: collapse;"><?php echo e($piutang->pasien->nama); ?></td>
            <td
                style="text-align:left;border:1px solid black;border-collapse: collapse;"><span><?php echo e($piutang->pasien->no_rm); ?></span>
            </td>
            <td
                style="text-align:center;border:1px solid black;border-collapse: collapse;"><?php echo e($piutang->tgl_masuk->format('d-M-y')); ?>

            </td>
            <td
                style="text-align:center;border:1px solid black;border-collapse: collapse;">
                <?php echo e($piutang->tgl_keluar->format('d-M-y')); ?></td>
            <td
                style="text-align:center;border:1px solid black;border-collapse: collapse;"><?php echo e($piutang->zaal); ?></td>
            <?php $__currentLoopData = $jenisPerawatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td
                style="text-align:center;border:1px solid black;border-collapse: collapse;">
                <?php if($piutang->biaya_perawatan->count()): ?>
                <?php
                $biaya = $piutang->biaya_perawatan
                ->where('jenis_perawatan_id', '=', $jenis->id)
                ->first()
                ->toArray()['biaya'];
                ?>

                <?php
                $total_biaya_perawatan[$jenis->id][] = $biaya;
                ?>

                <?php if($biaya): ?>
                <?php echo e(number_format($biaya, 0, '.', ',')); ?>

                <?php $total_biaya_perawatan[$jenis->id][] = $biaya ?>
                <?php endif; ?>
                <?php endif; ?>
            </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <td
                style="width:75px;text-align:center;border:1px solid black;border-collapse: collapse;">
                <?php if($piutang->biaya_perawatan->count()): ?>
                <?php
                $total = $piutang->biaya_perawatan->pluck('biaya')->sum();
                $total_total += $total;
                ?>
                <?php echo e(number_format($total, 0, '.', ',')); ?>

                <?php endif; ?>
            </td>
            
            <td
                style="width:75px;text-align:center;border:1px solid black;border-collapse: collapse;">
                <?php echo e(number_format($piutang->cicilan, 0, '.', ',')); ?>


                <?php
                $total_cicilan += $piutang->cicilan;
                ?>
            </td>
            
            <td
                style="width:75px;text-align:center;border:1px solid black;border-collapse: collapse;">
                <span>
                    <?php
                    $sisa = $total - $piutang->cicilan;
                    $total_sisa += $sisa;
                    ?>
                    <?php echo e(number_format($sisa, 0, '.', ',')); ?>

                </span>
            </td>
            <td
                style="width:75px;text-align:center;border:1px solid black;border-collapse: collapse;">
                <span></span>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <th
                style="text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;"
                colspan="6">Jumlah</th>
            <?php $__currentLoopData = $jenisPerawatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th
                style="text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;">
                <?php
                $t_bp = array_sum($total_biaya_perawatan[$jenis->id]);
                ?>
                <?php if($t_bp > 0): ?>
                <?php echo e(number_format($t_bp, 0, '.', ',')); ?>

                <?php endif; ?>
            </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th
                style="text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;">
                <?php echo e(number_format($total_total, 0, '.', ',')); ?>

            </th>
            <th
                style="text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;">
                <?php echo e(number_format($total_cicilan, 0, '.', ',')); ?>

            </th>
            <th
                style="text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;">
                <?php echo e(number_format($total_sisa, 0, '.', ',')); ?>

            </th>
            <th
                style="text-align:center;font-weight:bold;border:1px solid black;border-collapse: collapse;"></th>
        </tr>
    </tfoot>
</table>
<?php endif; ?>
<?php endfor; ?><?php /**PATH D:\Project\Laravel\piutang_rs\resources\views/exports/piutang.blade.php ENDPATH**/ ?>