@props(['width' => 110,'height'=>32])
<img src="/static/logo.svg" width="$width" height="$height"
    alt="Tabler" class="navbar-brand-image">