<table>
    <tr>
        <td>Data tidak tersedia</td>
    </tr>
</table>