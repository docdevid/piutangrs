import Litepicker from 'litepicker';
window.Litepicker = Litepicker