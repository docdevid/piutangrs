<?php

namespace App\Http\Controllers;

use App\Models\BiayaPerawatan;
use App\Http\Requests\StoreBiayaPerawatanRequest;
use App\Http\Requests\UpdateBiayaPerawatanRequest;

class BiayaPerawatanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreBiayaPerawatanRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(BiayaPerawatan $biayaPerawatan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(BiayaPerawatan $biayaPerawatan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateBiayaPerawatanRequest $request, BiayaPerawatan $biayaPerawatan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(BiayaPerawatan $biayaPerawatan)
    {
        //
    }
}
