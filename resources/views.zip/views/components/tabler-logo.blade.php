@props(['width' => 110,'height'=>32])
<img src="{{secure_asset('static/logo.svg')}}" width="$width" height="$height"
    alt="Tabler" class="navbar-brand-image">