@props(['width' => 110,'height'=>32])
<img src="{{asset('static/logo.svg')}}" width="$width" height="$height"
    alt="Tabler" class="navbar-brand-image">